from django.apps import AppConfig


class SimplemfaConfig(AppConfig):
    name = 'simplemfa'
