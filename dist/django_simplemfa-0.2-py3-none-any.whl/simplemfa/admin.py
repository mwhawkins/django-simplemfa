from django.contrib import admin
from simplemfa.models import AuthCode


admin.site.register(AuthCode)
